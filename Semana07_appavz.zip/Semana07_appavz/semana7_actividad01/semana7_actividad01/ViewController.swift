import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    // definir los arreglos que carguen los nombres e imagenes
    var personasArreglo = ["Jaime Gomez", "Juan León", "Silvia Montoya", "Theo Diaz", "Elliot Garamendi"]
    var personasImagenarreglo = ["icons", "icons", "icons", "icons", "icons"]

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personasArreglo.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "miCell") as? PersonasTableViewCell
        
        cell?.personaNombre.text = "\(personasArreglo[indexPath.row])"
        cell?.PersonaImagen.image = UIImage(named: "\(personasImagenarreglo[indexPath.row])")
        
        return cell!
    }

    // Código para generar la alerta
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alerta = UIAlertController(title: "El Docente que Selecciono es : ", message: "\(personasArreglo[indexPath.row])", preferredStyle: UIAlertController.Style.alert)
        
        // activar el botón OK
        alerta.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: { (action: UIAlertAction) in
        }))
        
        self.present(alerta, animated: true, completion: nil)
    }
}
