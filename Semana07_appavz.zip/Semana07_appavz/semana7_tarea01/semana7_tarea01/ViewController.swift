import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    var culturasArreglo: [Cultura] = [
        Cultura(nombre: "Chavín", region: "Áncash", descripcion: "Considerada la cultura matriz de la civilización andina, famosa por sus templos de piedra y el Lanzón Monolítico.", imagen: "icons1"),
        Cultura(nombre: "Paracas", region: "Ica", descripcion: "Reconocida por sus impresionantes mantos textiles y sus avanzadas prácticas de trepanación craneal.", imagen: "paracas"),
        Cultura(nombre: "Moche", region: "La Libertad", descripcion: "Famosa por su cerámica realista (huacos retratos) y sus impresionantes pirámides de adobe.", imagen: "moche"),
        Cultura(nombre: "Nazca", region: "Ica", descripcion: "Mundialmente conocida por las Líneas de Nazca, gigantescos geoglifos trazados en el desierto.", imagen: "nazca"),
        Cultura(nombre: "Wari", region: "Ayacucho", descripcion: "El primer imperio andino que expandió su urbanismo y red de caminos por gran parte del Perú.", imagen: "wari")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return culturasArreglo.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "culturaCell", for: indexPath) as! CulturaTableViewCell
        let cultura = culturasArreglo[indexPath.row]

        cell.culturaNombreLabel.text = cultura.nombre
        cell.culturaImagen.image = UIImage(named: cultura.imagen)

        return cell
    }

    // Método para la selección con ventana emergente (Alerta)
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cultura = culturasArreglo[indexPath.row]

        // Crear la alerta (ventana emergente) como en la actividad anterior
        let alerta = UIAlertController(title: "La Cultura que Selecciono es : ", message: "\(cultura.nombre)", preferredStyle: .alert)

        // Al presionar OK en la alerta, se navega al detalle
        alerta.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction) in
            self.performSegue(withIdentifier: "irADetalle", sender: cultura)
        }))

        self.present(alerta, animated: true, completion: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "irADetalle" {
            if let destino = segue.destination as? DetalleViewController,
               let cultura = sender as? Cultura {
                destino.culturaSeleccionada = cultura
            }
        }
    }
}
