import UIKit

class DetalleViewController: UIViewController {

    @IBOutlet weak var imagenCultura: UIImageView!
    @IBOutlet weak var nombreCultura: UILabel!
    @IBOutlet weak var regionCultura: UILabel!
    @IBOutlet weak var descripcionCultura: UITextView!

    var culturaSeleccionada: Cultura?

    override func viewDidLoad() {
        super.viewDidLoad()

        if let cultura = culturaSeleccionada {
            nombreCultura.text = cultura.nombre
            regionCultura.text = "Región: \(cultura.region)"
            descripcionCultura.text = cultura.descripcion
            imagenCultura.image = UIImage(named: cultura.imagen)
        }
    }
}
